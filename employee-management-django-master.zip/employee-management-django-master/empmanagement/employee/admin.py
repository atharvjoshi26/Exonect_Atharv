from django.contrib import admin
from employee.models import Employee,Attendance,Notice

# Register your models here.

# Register your models here.
admin.site.register(Employee)
admin.site.register(Attendance)
admin.site.register(Notice)